#js_utils
from selenium import webdriver

import time
globalHolder = {
    'driver': ''
}
def initJS(_url):
    globalHolder['driver'] = webdriver.Firefox()
    globalHolder['driver'].get(_url)
    return

# 调用js
def executeJS(js):
    if len(js) > 0:
        globalHolder['driver'].execute_script(js)
        time.sleep(3)
    return

def clickDom(dom_id):
    globalHolder['driver'].find_element_by_id(dom_id).click()
    time.sleep(3)
    return

def quitDriver():
    globalHolder['driver'].quit()
    return

