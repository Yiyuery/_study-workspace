#coding=utf-8
#_author_='xcy'

print("hello world!");